/*
 * Copyright 2023-present HiveMQ GmbH
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.hivemq.edge.adapters.${nameLC};

import com.codahale.metrics.MetricRegistry;
import com.hivemq.edge.adapters.${nameLC}.impl.${nameUC}ConnectorImpl;
import com.hivemq.edge.modules.adapters.ProtocolAdapterException;
import com.hivemq.edge.modules.adapters.data.ProtocolAdapterDataSample;
import com.hivemq.edge.modules.adapters.impl.AbstractPollingPerSubscriptionAdapter;
import com.hivemq.edge.modules.adapters.impl.AbstractPollingProtocolAdapter;
import com.hivemq.edge.modules.adapters.params.ProtocolAdapterStartInput;
import com.hivemq.edge.modules.adapters.params.ProtocolAdapterStartOutput;
import com.hivemq.edge.modules.api.adapters.ProtocolAdapterInformation;
import com.hivemq.edge.modules.config.impl.AbstractProtocolAdapterConfig;
import com.hivemq.extension.sdk.api.annotations.NotNull;
import com.hivemq.extension.sdk.api.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.CompletableFuture;

/**
 * @author HiveMQ Adapter Generator
 */
public class ${nameUC}ProtocolAdapter extends AbstractPollingPerSubscriptionAdapter<${nameUC}AdapterConfig, ProtocolAdapterDataSample> {

    private static final Logger log = LoggerFactory.getLogger(${nameUC}ProtocolAdapter.class);
    private volatile @Nullable I${nameUC}Client client;

    public ${nameUC}ProtocolAdapter(final @NotNull ProtocolAdapterInformation adapterInformation,
                             final @NotNull ${nameUC}AdapterConfig adapterConfig,
                             final @NotNull MetricRegistry metricRegistry) {
        super(adapterInformation, adapterConfig, metricRegistry);
    }

    @Override
    protected CompletableFuture<ProtocolAdapterStartOutput> startInternal(final @NotNull ProtocolAdapterStartOutput output) {
        CompletableFuture<I${nameUC}Client> startFuture =
                CompletableFuture.supplyAsync(() -> initConnection());
        startFuture.thenAccept((client) -> {
            client.connect();
            setConnectionStatus(ConnectionStatus.CONNECTED);
        }).thenRun(() -> subscribeAllInternal(client));
        return startFuture.thenApply(connection -> output);
    }

    private I${nameUC}Client initConnection() {
        if (client == null) {
            synchronized (lock) {
                if (client == null) {
                    log.info("Creating new Instance Of ${nameUC} Connector with {}", adapterConfig);
                    client = new ${nameUC}ConnectorImpl(adapterConfig);
                }
            }
        }
        return client;
    }

    protected void subscribeAllInternal(@NotNull final I${nameUC}Client client) throws RuntimeException {
        if (adapterConfig.getSubscriptions() != null) {
            for (${nameUC}AdapterConfig.Subscription subscription : adapterConfig.getSubscriptions()) {
                subscribeInternal(client, subscription);
            }
        }
    }

    protected void subscribeInternal(@NotNull final I${nameUC}Client client, final @NotNull ${nameUC}AdapterConfig.Subscription subscription) {
        if (subscription != null) {
            startPolling(new SubscriptionSampler(this.adapterConfig, subscription));
        }
    }

    @Override
    protected CompletableFuture<ProtocolAdapterDataSample> onSamplerInvoked(
            final ${nameUC}AdapterConfig config,
            final AbstractProtocolAdapterConfig.Subscription subscription) {

        if(client != null && client.isConnected()){
            byte myDatapoint = 0x2A; // initialise tag value to decimal 42
            ProtocolAdapterDataSample data = new ProtocolAdapterDataSample(myDatapoint, 
                subscription.getDestination(), 
                subscription.getQos());
            return CompletableFuture.completedFuture(data);    
        } else {
            return CompletableFuture.failedFuture(new IllegalStateException("Client <null> or not connected"));
        }
    }

    @Override
    protected CompletableFuture<Void> stopInternal() {
        if (client != null) {
            return CompletableFuture.runAsync(() -> {
                // Your runnable code here
                client.disconnect();
            });
        }
        return CompletableFuture.completedFuture(null);
    }
}
