/*
 * Copyright 2023-present HiveMQ GmbH
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.hivemq.edge.adapters.${nameLC};

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hivemq.edge.modules.adapters.annotations.ModuleConfigField;
import com.hivemq.edge.modules.config.CustomConfig;
import com.hivemq.extension.sdk.api.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class ${nameUC}AdapterConfig implements CustomConfig {

    @JsonProperty("id")
    @ModuleConfigField(title = "Identifier",
            description = "Unique identifier for this protocol adapter",
            format = ModuleConfigField.FieldType.IDENTIFIER,
            required = true,
            stringPattern = ID_PATTERN,
            stringMinLength = 1,
            stringMaxLength = 1024)
    private @NotNull String id;

    @JsonProperty("port")
    @ModuleConfigField(title = "Port",
            description = "The port number on the device you wish to connect to",
            required = true,
            numberMin = PORT_MIN,
            numberMax = PORT_MAX)
    private int port;

    @JsonProperty("host")
    @ModuleConfigField(title = "Host",
            description = "IP Address or hostname of the device you wish to connect to",
            required = true,
            format = ModuleConfigField.FieldType.HOSTNAME)
    private @NotNull String host;

    @JsonProperty("publishingInterval")
    @ModuleConfigField(title = "Publishing interval [ms]",
            description = "Publishing interval in milliseconds for this subscription on the server",
            numberMin = 1,
            required = true,
            defaultValue = "1000")
    private int publishingInterval = DEFAULT_PUBLISHING_INTERVAL; //1 second

    @JsonProperty("maxPollingErrorsBeforeRemoval")
    @ModuleConfigField(title = "Max. Polling Errors",
            description = "Max. errors polling the endpoint before the polling daemon is stopped",
            numberMin = 3,
            defaultValue = "10")
    private int maxPollingErrorsBeforeRemoval = DEFAULT_MAX_POLLING_ERROR_BEFORE_REMOVAL;

    @JsonProperty("publishChangedDataOnly")
    @ModuleConfigField(title = "Only publish data items that have changed since last poll",
            defaultValue = "true",
            format = ModuleConfigField.FieldType.BOOLEAN)
    private boolean publishChangedDataOnly = true;

    @JsonProperty("subscriptions")
    @ModuleConfigField(title = "Subscriptions",
            description = "Map your sensor data to MQTT Topics")
    private @NotNull List<Subscription> subscriptions = new ArrayList<>();

    public ${nameUC}AdapterConfig() {
    }

    public boolean getPublishChangedDataOnly() {
        return publishChangedDataOnly;
    }

    public int getMaxPollingErrorsBeforeRemoval() {
        return maxPollingErrorsBeforeRemoval;
    }

    public @NotNull String getId() {
        return id;
    }

    public int getPort() {
        return port;
    }

    public @NotNull String getHost() {
        return host;
    }

    public int getPublishingInterval() {
        return publishingInterval;
    }

    public @NotNull List<Subscription> getSubscriptions() {
        return subscriptions;
    }

    public static class Subscription {

        @JsonProperty("tag-name")
        private @NotNull String tagName;

        @JsonProperty("destination")
        @ModuleConfigField(title = "Destination MQTT topic",
                description = "The MQTT topic to publish to",
                format = ModuleConfigField.FieldType.MQTT_TOPIC,
                required = true)
        private @NotNull String destination;

        @JsonProperty("qos")
        @ModuleConfigField(title = "MQTT QoS",
                description = "MQTT quality of service level",
                numberMin = 0,
                numberMax = 2,
                defaultValue = "0")
        private @NotNull int qos = 0;


        public @NotNull String getTagName() {
            return tagName;
        }

        public @NotNull String getDestination() {
            return destination;
        }

        public int getQos() {
            return qos;
        }
    }
}
